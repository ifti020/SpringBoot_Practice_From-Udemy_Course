package com.ifti.springcoredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcoredemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
